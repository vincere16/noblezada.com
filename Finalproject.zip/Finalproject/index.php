<!DOCTYPE html>
<html>
<body>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
	<div class="container">
            <div class="box">
                <br>
            
                <h4 class="display-4 text-center"><b>SELECT USER</b></h4><hr><br>
		<form action="php/create.php" 
		      method="post">
                    <img src="icon.png"  width="300" height="300">
                   
                   
		<h1 class="display-5 text-center"> <a href="admin.php" class="link-primary"><b>ADMIN</b></h1></a>
                <h1 class="display-5 text-center"><a href="search.php" class="link-primary"><b>END USER</b></h1></a>
                         
        
	    </form>
	</div>
            
</body>
</html> 